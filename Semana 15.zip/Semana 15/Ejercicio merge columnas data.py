import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
# Cargar arhivos
df1 = pd.read_csv("Productosoffice.csv")
df2 = pd.read_csv("Ventasproductos.csv")
# Merge
dfresult = pd.merge(df1,df2, on="Codigo", how="inner")
dfresult2 = pd.merge(df1,df2, on="Codigo", how="outer")
print(f"Mostrar DataFrame con inner join {dfresult}")
print(f"Mostrar DataFrame con outer join {dfresult2}")
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
# Cargar los archivos CSV
df1=pd.read_csv('Ventasnetas.csv')
df2=pd.read_csv('Devolucionesnetas.csv')
# Concatenar por columnas
dfresult=pd.concat([df1,df2], axis=1)
# Mostrar Data
print("DataFrame Concatenado")
print(dfresult)
# Seccion EDA 
# DataFrame COMPELTO
print(dfresult.to_string)
#Copia
df_original=dfresult.copy()
print(dfresult.describe())
print(dfresult.info())
# Limpieza de datos
# Eliminar espacios innecesarios
dfresult.columns=dfresult.columns.str.strip()
print(dfresult.info())
# Cambiar nombre a columnas
dfresult.rename(columns={"VENTAS A O 2022": "VENTAS 2022"}, inplace=True)
dfresult.rename(columns={"VENTAS A O 2023": "VENTAS 2023"}, inplace=True)
dfresult.rename(columns={"DEVOLUCIONES A O 2022": "DEVOLUCIONES 2022"}, inplace=True)
dfresult.rename(columns={"DEVOLUCIONES A O 2023": "DEVOLUCIONES 2023"}, inplace=True)
print("DataFrame actualizado")
print(dfresult.info())
# Limpieza de datos ventas y devoluciones
dfresult["VENTAS 2022"]=dfresult["VENTAS 2022"].replace({"\$":"",",":""," ":"","\.":""},regex=True)
dfresult["VENTAS 2023"]=dfresult["VENTAS 2023"].replace({"\$":"",",":""," ":"","\.":""},regex=True)
dfresult["DEVOLUCIONES 2022"]=dfresult["DEVOLUCIONES 2022"].replace({"\$":"",",":""," ":"","\.":""},regex=True)
dfresult["DEVOLUCIONES 2023"]=dfresult["DEVOLUCIONES 2023"].replace({"\$":"",",":""," ":"","\.":""},regex=True)
print("DataFrame actualizado")
print(dfresult.info())
print(dfresult)
# Convertir columnas object a int 
dfresult["VENTAS 2022"]=dfresult["VENTAS 2022"].astype(int)
dfresult["VENTAS 2023"]=dfresult["VENTAS 2023"].astype(int)
dfresult["DEVOLUCIONES 2022"]=dfresult["DEVOLUCIONES 2022"].astype(int)
dfresult["DEVOLUCIONES 2023"]=dfresult["DEVOLUCIONES 2023"].astype(int)
print(dfresult.info())
# Verificar tipo de datos
print("La columna de Ventas 2022 es de tipo")
print(dfresult["VENTAS 2022"].dtype)
#Limpieza de datos cambiar nombre de datos
dfresult["ZONA"]=dfresult["ZONA"].replace("Medellin","Medellín")
dfresult["ZONA"]=dfresult["ZONA"].replace("Bogot ","Bogotá")
print(dfresult["ZONA"])
# Área de estadistica
# Crear nueva columna con la diferencia
dfresult["DIFERENCIA 2023"]=dfresult["VENTAS 2023"]-dfresult["DEVOLUCIONES 2023"]
dfresult["DIFERENCIA 2022"]=dfresult["VENTAS 2022"]-dfresult["DEVOLUCIONES 2022"]
total_ventas = dfresult["VENTAS 2023"].sum()
total_devoluciones = dfresult["DEVOLUCIONES 2023"].sum()
total_ventasnetas = dfresult["DIFERENCIA 2023"].sum()
# Imprimir datos
print(f"Total de ventas 2023 ${total_ventas}")
print(f"Total de devoluciones 2023 ${total_devoluciones}")
print(f"Total de ventas netas 2023 ${total_ventasnetas}")
# Calcular porcentaje de devoluciones 
dfresult["%_DEVOL/VENTAS 2023"] = (dfresult["DEVOLUCIONES 2023"]/dfresult["VENTAS 2023"])*100
# Calcular incremento de venta
dfresult["%_INCREM_VENTAS 2023"] = (dfresult["VENTAS 2023"]/dfresult["VENTAS 2022"]) - 1
print(dfresult[["NOMBRE","ZONA","VENTAS 2023","DIFERENCIA 2023","%_INCREM_VENTAS 2023"]])
# Filtrado de datos 
# Filtrar ventas mayores o iguales a 10.000.000 
print("Ventas >= $10.000.000")
print(dfresult.loc[dfresult["VENTAS 2023"]>=10000000])
# Top 5 ventas 
print("5 Ventas más altas")
top_5_altasventas2023=dfresult.nlargest(5,"VENTAS 2023")
print(top_5_altasventas2023)
print("5 Ventas más bajas")
top_5_bajasventas2023=dfresult.nsmallest(5,"VENTAS 2023")
print(top_5_bajasventas2023)
# Visualizacion
# Grafico de barras 
plt.figure(figsize=(10,6))
plt.plot(dfresult["VENTAS 2023"],marker="o",linestyle="-",color="b",label="Ventas")
plt.title("GRAFICA DE VENTAS")
plt.xlabel("INDICE")
plt.ylabel("Valor ventas")
plt.legend()
plt.grid(True)
plt.xticks(rotation=45)
plt.show()
plt.savefig("grafico_barras.png")
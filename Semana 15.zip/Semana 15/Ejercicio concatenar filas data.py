import pandas as pd
import numpy as np
import seaborn as sns
import matplotlib.pyplot as plt
# Cargar archivos csv
df1 = pd.read_csv("ventasbogota.csv")
df2 = pd.read_csv("ventascali.csv")
df3 = pd.read_csv("ventasmedellin.csv")
df4 = pd.read_csv("ventasquilla.csv")
# Concatenar por filas
dfresult = pd.concat([df1,df2,df3,df4],axis=0)
# Seccion EDA 
# DataFrame COMPELTO
print(dfresult.to_string)
#Copia
df_original=dfresult.copy()
print(dfresult.describe())
print(dfresult.info())
# Limpieza de datos
# Eliminar espacios innecesarios
dfresult.columns=dfresult.columns.str.strip()
print(dfresult.info())
# Cambiar nombre de columna Ventas año 2022 a ventas 2023
dfresult.rename(columns={"VENTAS AÑO 2022": "VENTAS 2022"}, inplace=True)
dfresult.rename(columns={"VENTAS AÑO 2023": "VENTAS 2023"}, inplace=True)
print("Mostrar DataFrame actualizado")
print(dfresult.info())
# Depurar datos columna ventas 2022 y 2023
dfresult["VENTAS 2022"]=dfresult["VENTAS 2022"].replace({"\$":"",",":""," ":"","\.":""},regex=True)
dfresult["VENTAS 2023"]=dfresult["VENTAS 2023"].replace({"\$":"",",":""," ":"","\.":""},regex=True)
# Convertir tipos de datos de columnas
dfresult["VENTAS 2022"]=dfresult["VENTAS 2022"].astype(int)
dfresult["VENTAS 2023"]=dfresult["VENTAS 2023"].astype(int)
print("DataFrame actualizado")
print(dfresult.info())
#Limpieza de datos cambiar nombre de datos
dfresult["CIUDAD"]=dfresult["CIUDAD"].replace("Medellin","Medellín")
dfresult["CIUDAD"]=dfresult["CIUDAD"].replace("Bogota","Bogotá")
print(f"DataFrame depurado {dfresult["CIUDAD"]}")
# Estadisticas de informes de agrupación
informe_ventas_canal = dfresult.groupby("CANAL")["VENTAS 2023"].sum().reset_index()
print(f"Informe de ventas consolidadas por canal {informe_ventas_canal}")
pivot_table = pd.pivot_table(dfresult,values="VENTAS 2023",index=["CIUDAD","CANAL"],aggfunc="sum",fill_value=0)
print(pivot_table)
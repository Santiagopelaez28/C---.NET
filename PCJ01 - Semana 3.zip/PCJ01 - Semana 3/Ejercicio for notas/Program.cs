﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_for_notas
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int K;
            Console.WriteLine("Ingrese cantidad de estudiantes a calificar: ");
            int cant = int.Parse(Console.ReadLine());
            double sum, prom;
            sum = prom = 0;     //Asignacion multiple
            for (K = 1; K <= cant; K++)
            {
                // Ingreso de notas de estudiantes
                Console.WriteLine("Nombre de estudiante: ");
                string nom = Console.ReadLine();
                //1era nota
                Console.WriteLine("Nota 1: ");
                double nota1 = double.Parse(Console.ReadLine());
                //2da nota
                Console.WriteLine("Nota 2: ");
                double nota2 = double.Parse(Console.ReadLine());
                //3era nota
                Console.WriteLine("Nota 3: ");
                double nota3 = double.Parse(Console.ReadLine());
                // Calculo de nota final del estudiante
                prom = (nota1 + nota2 + nota3)/3;
                Console.WriteLine($"El promedio final del estudiante {nom} es de: {prom}");
                sum += prom;        // Acumulador de notas finales de estudantes
            }
            Console.WriteLine();
            // Imprime promedio del grupo - salon
            Console.WriteLine($"El promedio final de los {cant} estudiantes es de {sum/cant}");
            Console.WriteLine("Pulse una tecla para finalizar");
            Console.ReadKey();
        }
    }
}

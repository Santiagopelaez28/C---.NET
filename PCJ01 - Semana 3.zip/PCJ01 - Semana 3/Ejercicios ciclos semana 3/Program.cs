﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicios_ciclos_semana_3
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int K;
            int RESUL = 1;
            // Entrada de datos
            Console.WriteLine("Ingrese un número: ");
            int NUM = int.Parse(Console.ReadLine());
            // Seccion de ciclo for
            for (K = 2; K <= NUM; K++)
            {
                RESUL *= K;
            }
            //Salida de datos
            Console.WriteLine($"El factorial de {NUM} es: {RESUL}");
            Console.Write("Pulse una tecla para continuar.");
            Console.ReadKey();
        }
    }
}

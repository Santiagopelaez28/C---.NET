﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_fanctura_setcursorposition
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double pre = 0;
            double tot = 0;
            double paga = 0;
            char OP;
            int fi = 6;   //Número de la fila de la consola a imprimir detalle de factura
            // Seccion de posicionamiento del cursor en la consola de C# 
            Console.SetCursorPosition(5, 4);       // Columna 5 con fila 4
            Console.Write("PRODUCTO   CANTIDAD   PRECIO   TOTAL");
            // Se configura el do while
            do
            {
                Console.SetCursorPosition(5, fi);
                string prod = Console.ReadLine();
                //
                Console.SetCursorPosition(17, fi);
                int cant = int.Parse(Console.ReadLine());
                //
                Console.SetCursorPosition(28, fi);
                pre = double.Parse(Console.ReadLine());
                // Calcula valor a pagar producto
                tot = cant * pre;
                //
                Console.SetCursorPosition(35, fi);
                Console.Write(tot);
                // Calcular el valor total neto a pagar
                paga += tot;
                fi += 2;
                //
                Console.SetCursorPosition(32, 23);
                Console.Write("¿Desea comprar otro producto? [S/N]: ");
                // Convierte de string a char y luega pasa respuesta a mayuscula
                OP = char.Parse(Console.ReadLine().ToUpper());
            } while (OP.ToString().Equals("S"));
            Console.WriteLine($"El total a pagar es: {paga}");
            Console.WriteLine("Pulse una tecla para finalizar");
            Console.ReadKey();
        }
    }
}

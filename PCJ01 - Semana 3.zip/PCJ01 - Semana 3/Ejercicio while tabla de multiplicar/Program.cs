﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_while_tabla_de_multiplicar
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int I, resul;
            Console.WriteLine("Dijite tabla de multiplicar del número: ");
            int num = int.Parse(Console.ReadLine());
            I = 1;
            // Seccion del ciclo while
            while (I <= 12)
            {
                // Proceso
                resul = num * I;
                Console.WriteLine("{0} * {1} = {2}", num, I, resul);
                I++;
            }
            Console.WriteLine("Pulse una tecla para finalizar");
            Console.ReadKey();
        }
    }
}

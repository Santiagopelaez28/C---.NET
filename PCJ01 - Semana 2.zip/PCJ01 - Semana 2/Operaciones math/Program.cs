﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Operaciones_math
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Asignacion de variables
            float n1, n2, r1, r2, r3, r4;
            Console.WriteLine("Ingrese el primer número: ");
            n1 = float.Parse(Console.ReadLine());
            Console.WriteLine("Ingrese el segundo número: ");
            n2 = float.Parse(Console.ReadLine());
            Console.WriteLine("");
            // Suma
            r1 = n1 + n2;
            Console.Write($"La suma de los números es: {r1}\n");
            Console.Write(n1);
            Console.Write(" + ");
            Console.Write(n2);
            Console.Write(" = ");
            Console.WriteLine(r1);
            // Resta 
            r2 = n1 - n2;
            Console.Write($"La resta de los números es: {r2}\n");
            Console.Write(n1);
            Console.Write(" - ");
            Console.Write(n2);
            Console.Write(" = ");
            Console.WriteLine(r2);
            // Multiplicación
            r3 = n1 * n2;
            Console.Write($"La multiplicación de los números es: {r3}\n");
            Console.Write(n1);
            Console.Write(" x ");
            Console.Write(n2);
            Console.Write(" = ");
            Console.WriteLine(r3);
            // División
            r4 = n1 / n2;
            Console.Write($"La división de los números es: {r4}\n");
            Console.Write(n1);
            Console.Write(" / ");
            Console.Write(n2);
            Console.Write(" = ");
            Console.WriteLine(r4);
            Console.ReadLine();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Salario_vhora
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Ingrese el número de horas trabajadas: ");
            int horas = int.Parse(Console.ReadLine());
            Console.Write("Ingrese el valor de la hora: ");
            int vhora = int.Parse(Console.ReadLine());
            // Proceso de liquidación pago empleado
            int neto = horas * vhora;
            Console.Write($"El valor a cancelar es de ${neto} por las {horas} horas trabajadas");
            Console.ReadKey();
        }
    }
}
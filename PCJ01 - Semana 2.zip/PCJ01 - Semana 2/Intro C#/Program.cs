﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Intro_C_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            string nombre, ed, esta, curso;     // Asignacion de variables
            int edad;
            float estatura;
            // Entrada de datos
            Console.WriteLine("Ingrese nombre del estudiante: ");
            nombre = Console.ReadLine();
            Console.WriteLine("Ingrese el curso inscrito: ");
            curso = Console.ReadLine();
            Console.WriteLine("Ingrese edad del estudiante: ");
            ed = Console.ReadLine();
            edad = int.Parse(ed);
            Console.WriteLine("Ingrese estatura del estudiante: ");
            esta = Console.ReadLine();
            estatura = float.Parse(esta);
            // Salida
            Console.WriteLine("");
            Console.WriteLine("El nombre del estudiante ingresado es: ");
            Console.WriteLine(nombre);
            Console.WriteLine("El curso matriculado del estudiante es: ");
            Console.WriteLine(curso);
            Console.WriteLine("La edad actual del estudiante es: ");
            Console.WriteLine(edad);
            Console.WriteLine("La estatura del estudiante es de :");
            Console.WriteLine(estatura + " " + "mts");
            Console.ReadKey();
        }
    }
}
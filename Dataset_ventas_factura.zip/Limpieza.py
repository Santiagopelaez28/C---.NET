import pandas as pd

# Importar el dataset csv
df = pd.read_csv("ventas-por-factura.csv")
# Hacer copia de dataframe
df = df.copy()

# Limpieza de datos 
df.columns = df.columns.str.strip()

# Cambiar tipo de datos 
df["Fecha de factura"] = pd.to_datetime(df["Fecha de factura"])     # Columna fecha de factura a tipo datetime
na_indices = df["ID Cliente"].isna()        # Buscar datos NaN en la columna Id cliente
df.loc[na_indices,"ID Cliente"] = range(1000,1000 + na_indices.sum())       # Rellenar datos vacios y NaN con números incrementados
df["ID Cliente"] = df["ID Cliente"].round(0).astype(int)        # Columna ID Cliente a tipo int64
df["Monto"] = df["Monto"].str.replace(',','.')      # Cambiar las comas ',' por puntos '.' en la columna de monto
df["Monto"] = df["Monto"].astype(float)     # Convertir a float64 la columna monto desde string

# Reemplazar nombres de pais 
df["País"] = df["País"].replace('United Kingdom','Reino Unido')
df["País"] = df["País"].replace('Netherlands','Países Bajos')
df["País"] = df["País"].replace('EIRE','Irlanda')
df["País"] = df["País"].replace('Germany','Alemania')
df["País"] = df["País"].replace('France','Francia')
df["País"] = df["País"].replace('Switzerland','Suiza')
df["País"] = df["País"].replace('Spain','España')
df["País"] = df["País"].replace('Belgium','Bélgica')
df["País"] = df["País"].replace('Sweden','Suecia')
df["País"] = df["País"].replace('Japan','Japón')
df["País"] = df["País"].replace('Norway','Noruega')
df["País"] = df["País"].replace('Finland','Finlandia')
df["País"] = df["País"].replace('Channel Islands','Islas del Canal')
df["País"] = df["País"].replace('Denmark','Dinamarca')
df["País"] = df["País"].replace('Italy','Italia')
df["País"] = df["País"].replace('Cyprus','Chipre')
df["País"] = df["País"].replace('Singapore','Singapur')
df["País"] = df["País"].replace('Poland','Polonia')
df["País"] = df["País"].replace('Unspecified','No especificado')
df["País"] = df["País"].replace('Greece','Grecia')
df["País"] = df["País"].replace('Iceland','Islandia')
df["País"] = df["País"].replace('Canada','Canadá')
df["País"] = df["País"].replace('United Arab Emirates','Emiratos Arabes Unidos')
df["País"] = df["País"].replace('USA','Estados Unidos')
df["País"] = df["País"].replace('Lebanon','Líbano')
df["País"] = df["País"].replace('Lithuania','Lituania')
df["País"] = df["País"].replace('European Community','Comunidad Europea')
df["País"] = df["País"].replace('Brazil','Brasil')
df["País"] = df["País"].replace('RSA','Sudáfrica')
df["País"] = df["País"].replace('Czech Republic','Republica Checa')
df["País"] = df["País"].replace('Bahrain','Baréin')
df["País"] = df["País"].replace('Saudi Arabia','Arabia Saudita')

df.to_csv("Dataset_ventas_factura.csv", index=False)
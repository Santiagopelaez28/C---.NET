﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace Excepcion_do_while
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bool continua;      // Variable tipo booleana - Falso o Verdadero
            do
            {
                try
                {
                    continua = false;
                    Console.Write("Ingrese un valor entero: ");
                    int num = int.Parse(Console.ReadLine());
                    var cuadrado = num * num;
                    Console.WriteLine($"El cuadrado del {num} es {cuadrado}");
                }
                catch (FormatException)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Error, debe ingresar numeros enteros");
                    continua = true;
                    Console.ResetColor();
                }
            }
            while (continua);
            Console.ReadKey();
        }
    }
}

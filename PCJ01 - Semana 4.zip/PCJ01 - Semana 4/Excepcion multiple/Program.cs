﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Excepcion_multiple
{
    internal class Program
    {
        static void Main(string[] args)
        {
			try
			{
				Console.Write("Ingrese el primer valor: ");
				decimal num1 = decimal.Parse(Console.ReadLine());
				Console.Write("Ingrese segundo valor: ");
                decimal num2 = decimal.Parse(Console.ReadLine());
                // Proceso
                decimal resu = num1 / num2;
                // Salida 
                Console.WriteLine($"La division del {num1} entre el {num2} es igual a: {resu}");
            }
            catch (FormatException ex)
			{
                Console.ForegroundColor = ConsoleColor.Red;     // Mensaje con color de letra rojo
                Console.WriteLine("Error, ingrese un número entero");
                Console.ResetColor();
            }
            catch (DivideByZeroException ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;     // Mensaje con color de letra rojo
                Console.WriteLine("Error, Ingrese un valor diferente de cero");
                Console.ResetColor();
            }
            Console.ReadKey();
        }
    }
}

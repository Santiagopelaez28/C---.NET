﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Metadata.W3cXsd2001;
using System.Text;
using System.Threading.Tasks;

namespace Vector_sueldo_POO
{
    class Vector    //Plantilla de clase
    {
        // Atributos de clase - variables
        private int[] sueldos;
        // Metodo de clase, cargar vector
        public void cargar()
        {
            sueldos = new int[5];       // Matricular la cantidad en el vector
            // Ingreso de sueldos al vector
            for (int i = 0; i < sueldos.Length; i++)
            {
                Console.WriteLine("Ingrese el sueldo a guardar:");
                sueldos[i] = int.Parse(Console.ReadLine());
            }
        }
        // Metodo de clase imprimir vector
        public void imprimir()
        {
            for (int i = 0; i < sueldos.Length; i++)
            {
                Console.WriteLine($"Sueldo {i + 1}: " + sueldos[i]);
            }
            Console.ReadKey();
        }
        // Creación de objeto de clase y llamada de metodos 
        static void Main(string[] args)
        {
            Vector pvector = new Vector();      // Instanciar clase - Objeto
            pvector.cargar();       // Llamada a metodo cargar
            pvector.imprimir();     // Llamada a metodo imprimir
        }
        
    }
}

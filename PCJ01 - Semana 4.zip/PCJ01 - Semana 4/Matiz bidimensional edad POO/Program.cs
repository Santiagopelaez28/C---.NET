﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Matiz_bidimensional_edad_POO
{
    class Matriz    // Crea plantilla de clase 
    {
        private int[,] mat;     // Crea atributo de clase tipo matriz
        public void Cargar()    // Crea metodo de clase
        {
            Console.Write("Cuantas filas tiene la matriz: ");
            int filas = int.Parse(Console.ReadLine());
            //
            Console.Write("Cuantas columnas tiene la matriz: ");
            int columnas = int.Parse(Console.ReadLine());
            // Asignacion de valores de dimension de la matriz a atributo de clase
            mat = new int[filas, columnas];     // Crea objeto matriz
            for (int f = 0; f < mat.GetLength(0); f++)
            {
                for (int c = 0; c < mat.GetLength(1); c++)
                {
                    Console.Write("Ingrese edad del estudiante: ");
                    mat[f, c] = int.Parse(Console.ReadLine());
                }
            }
        }
        public void Imprimir()
        {
            for (int f = 0; f < mat.GetLength(0); f++)
            {
                for (int c = 0; c < mat.GetLength(1); c++)
                {
                    Console.Write(mat[f, c] + " ");
                }
                Console.WriteLine();
            }
        }
        // Creacion de metodo para generar promedio de edad
        public void GenerarPromedioEdad()
        {
            double suma, cont, prom;    // Variables del metodo
            suma = cont = prom = 0;     // Asignacion multiple de valor 0
            for (int f = 0; f < mat.GetLength(0); f++)
            {
                for (int c = 0;c < mat.GetLength(1);c++)
                {
                    suma += mat[f, c];      // Acumulador de edades
                    cont++;     // Contador de elementos en la matriz
                }
                Console.WriteLine();
            }
            prom = suma / cont;
            Console.Write($"El promedio de la edad de los estudiantes es de {Math.Round(prom, 2)}");
        }
        static void Main(string[] args)
        {
            Matriz ma = new Matriz();       //Crea objeto de clase - Instanciar clase
            ma.Cargar();        // Llamadas de metodos de clase
            ma.Imprimir();
            ma.GenerarPromedioEdad();
            Console.ReadKey();
        }
    }
}

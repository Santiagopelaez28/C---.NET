﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Vector_captura_datos
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Creación del vector - Array
            string[] nombres;       // Atributo de clase
            Console.WriteLine("Ingrese la cantidad de nombres a guardar: ");
            int cant = int.Parse(Console.ReadLine());
            nombres = new string[cant];     // Instanciar objeto vector con cantidad
            // Seccion de ingreso de nombres
            for (int i = 0; i < cant; i++)
            {
                Console.WriteLine("Nombre {0}:", i + 1);
                nombres[i] = Console.ReadLine();
            }
            // Inpresion de nombres guardados en Array
            Console.WriteLine();
            Console.WriteLine("--Presione una tecla para mostrar nombres--");
            Console.ReadKey();
            Console.WriteLine();
            Console.WriteLine("Los nombres guardados son: ");
            // Ciclo for
            for (int i = 0; i < nombres.Length; i++)
            {
                Console.WriteLine("{0}.{1}", i + 1, nombres[i]);
            }
            Console.ReadKey();
        }
    }
}
